even_numbers = list(range(2,11,2))
print(even_numbers)

# how big can I go? will it crash?
even_numbers = list(range(2, 401, 2))
print(even_numbers)

# 400 is a lot of numbers, but let's try BIGGER numbers.
even_numbers = list(range(2, 4001, 2))
print(even_numbers)

# not even a stutter? let's try four million
even_numbers = list(range(2, 4000001, 2))
print(even_numbers)

# WHOA. no hesitation. let's try 8e21 (8 quintillion) as the upper bound.
# even_numbers = list(range(2, int(8e21+1), 2))  # it throws an error if it's just 8e21 since that's a float
# print(even_numbers)

# 8e21 throws an error, so now we have some idea of some of the biggest numbers Python can handle.