# A basic list of fruit. I went with fruit because there's a lot of it.
fruits = ["mango", "kiwi", "pineapple", "blueberry", "strawberry", "peach", "lemon", "apple"]

# Copy the fruits into a food list.
# This would be a good way to make things inherit properties from each other, then add new properties.
food = fruits[:]

fruits.append("pear")
food.append("lettuce")

# It's interesting that assigning fruits to food causes the two to be permanently linked.
# That could also have some use for something.... hmm

print(f"Some examples of fruit:\n{fruits}")  # when would I ever not use an f-string?
print(f"Some more general examples of food:\n{food}")