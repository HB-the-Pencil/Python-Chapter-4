magicians = ["Alice", "David", "Carolina"]

for magician in magicians:
    print(f"{magician.title()} is very magical")
    print(f"I wish I could do magic as well as {magician.title()}")

print("this is not inside the for loop!")
print(f"magician is now defined as {magician}, the last value of magician. It throws an error in the editor but not in the console.")