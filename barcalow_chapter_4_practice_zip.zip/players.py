# If you get the reference, you get +10 cool points. (I hide references to things I like quite often.)
players = ["Wakka", "Datto", "Letty", "Jassu", "Botta", "Keepa"]

print(players[0:3])
print(players[:3])  # this is the same as [0:3]
print(players[3:])

# Look! We can print the first half of a list only!
print(players[:len(players)//2])
# and the second half, just by moving the colon! Good if you need to split data in half.
print(players[len(players)//2:])

# What is this third value they mention?
print(players[::2])
# aha! so I can print every other item in a list!

print("The first three players on the Besaid Aurochs are:")
[print(player) for player in players[:3]]  # HAHA I LEARNED LIST COMPREHENSION

# wait can I f-string that???
# print(f"The last three players on the Besaid Aurochs are:{[print(player) for player in players[3:]]}")
# nope. oh well.