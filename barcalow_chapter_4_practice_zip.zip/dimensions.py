# It's Tuple Time! (use your best Arnold Schwarzenegger voice to read that)
dimensions = (200, 50)
# dimensions[1] = 75
# tuples are immutable

# This would be good for a game where players pick a team at the very start, and it can't be changed.
# The team is set as an immutable tuple.

# List comprehension works for tuples! Would that be called tuple comprehension
[print(dimension) for dimension in dimensions]

# lol you can't do it in parentheses (just because it's a tuple),
# PyCharm says "Statement seems to have no effect"
# (print(dimension) for dimension in dimensions)

# Is there a way to make immutable values? Or must you create a one-item tuple?
singularTuple = ("e",)
print(singularTuple)

# Interestingly, tuples print with parentheses and not square brackets. Makes sense.

dimensions = (300, 50, 75)

# So you can't change tuples, but you can rewrite them... That's important.
# Are there any types of variables that cannot be changed, in any way, ever?

[print(dimension) for dimension in dimensions]