squares = []

# I shrank their code a bit. There doesn't need to be an intermediate variable.
# oh, darn. they point that out later :P
for value in range(1, 11):
    squares.append(value ** 2)

print(squares)

# what happens if...?
# alt_method_squares = list(range(1,11) ** 2)
# print(alt_method_squares)

# throws an error. Good to know.

# As it turns out, there IS a concise way to do it! and it looks super techy!
squares = [value**2 for value in range(1, 11)]
print(squares)