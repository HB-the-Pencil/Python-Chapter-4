# The first for loop with numbers!
for value in range(1,5):
    print(value)

# So there is no for (variable=0, max, increment) syntax like in JavaScript?
# Let's test something:
things = ["item", "thing", "miscellany", "object"]

# If my theory is correct, this loop will print each item in the list.
for value in range(len(things)):
    print(things[value])

# It works with no errors! It doesn't even need the 0 as the starting index.

numbers = list(range(1,6))
print(numbers)